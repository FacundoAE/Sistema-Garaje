<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Nosotros'); ?>
<?php $configuracion->setMenu('Nosotros'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    <div class="banner">
        <i class="fa fa-users fa-2x" aria-hidden="true"></i>
        <div>
            <h1>Nosotros</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis corporis rerum iusto in qui esse commodi mollitia, vero, distinctio dolores perferendis impedit, ex laborum nihil nobis vel aliquid quidem excepturi?</p>
        </div>
      </div>
    <div class="fondo">
        <img src="https://picsum.photos/200/200" alt="" srcset="">
        <div>
            <h1>Servicio</h1>
            <p>Descripción</p>
        </div>
    </div>
    <div class="fondo">
        <h1>Equipo</h1>
        <div>
        <img src="https://picsum.photos/100/100" alt="" srcset="">
        <div>
            <h1>Nombre</h1>
            <p>Descripción</p>
            <a href="http://">Redes Sociales</a>
        </div>
        </div>
        <div>
            <img src="https://picsum.photos/100/100" alt="" srcset="">
            <div>
                <h1>Nombre</h1>
                <p>Descripción</p>
                <a href="http://">Redes Sociales</a>
            </div>
        </div>
    </div>
</section>
<?php require_once('componentes/footer.php'); ?>