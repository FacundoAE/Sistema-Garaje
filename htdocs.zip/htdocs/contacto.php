<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Contacto'); ?>
<?php $configuracion->setMenu('Contacto'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    <div class="banner">
        <i class="fa fa-envelope fa-2x" aria-hidden="true"></i>
        <div>
            <h1>Contacto</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Asperiores laborum, ut culpa odit numquam odio voluptates eaque consectetur beatae officia rerum tempora esse nulla eum, sint error id! Odio, maxime?</p>
        </div>
    </div>
    <div id="contacto">
        <form action="" method="post">
            <div id="infoContacto">
                <label for="">Nombre y Apellido</label>
                <input type="text" name="nombreyapellido" minlength="12" maxlength="60" required>
                <label for="">Asunto</label>
                <input type="text" name="asunto" minlength="4" maxlength="80" required>
                <label for="">Correo electrónico</label>
                <input type="email" name="" maxlength="150" required>
                <label for="">Verificación</label>
                <div class="g-recaptcha" data-sitekey="6Lez52IfAAAAAL49t58t2sFJfE7nYwmg2M7ArC9g"></div>
                <input type="submit" value="Enviar">
            </div>
            <div id="msjContacto">
                <label for="">Mensaje</label>
                <textarea name="mensaje" cols="30" rows="10" wrap="hard" minlength="100" maxlength="3000" required></textarea>
            </div>
        </form>
    </div>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</section>
<?php require_once('componentes/footer.php'); ?>