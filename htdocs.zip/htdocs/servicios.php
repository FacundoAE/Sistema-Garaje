<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Servicios'); ?>
<?php $configuracion->setMenu('Servicios'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    <div class="banner">
        <i class="fa fa-desktop fa-2x" aria-hidden="true"></i>
        <div>
            <h1>Servicios</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis corporis rerum iusto in qui esse commodi mollitia, vero, distinctio dolores perferendis impedit, ex laborum nihil nobis vel aliquid quidem excepturi?</p>
        </div>
    </div>
    <div class="muestra">
        <div class="item">
            <div class="titulo">
                <h1>Web</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                    <li>Dos</li>
                    <li>Tres</li>
                </ul>
            </div>
            <a href="">Contacto</a>
        </div>
        <div class="item">
            <div class="titulo">
                <h1>Desktop</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                    <li>Dos</li>
                    <li>Tres</li>
                </ul>
            </div>
            <a href="">Contacto</a>
        </div>
        <div class="item">
            <div class="titulo">
                <h1>Análisis funcional</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                    <li>Dos</li>
                    <li>Tres</li>
                </ul>
            </div>
            <a href="">Contacto</a>
        </div>
    </div>
</section>
<?php require_once('componentes/footer.php'); ?>