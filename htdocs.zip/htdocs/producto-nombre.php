<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Productos'); ?>
<?php $configuracion->setMenu('Productos'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    
</section>
<?php require_once('componentes/footer.php'); ?>