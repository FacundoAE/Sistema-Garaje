<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Productos'); ?>
<?php $configuracion->setMenu('Productos'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    <div class="banner">
        <i class="fa fa-cubes fa-2x" aria-hidden="true"></i>
        <div>
            <h1>Productos</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis corporis rerum iusto in qui esse commodi mollitia, vero, distinctio dolores perferendis impedit, ex laborum nihil nobis vel aliquid quidem excepturi?</p>
        </div>
    </div>
    <div class="listado">
        <div class="item">
            <img src="https://picsum.photos/200/200" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <h1>Producto</h1>
                <p>Descripción</p>
                <a href="">Ver más</a>
            </div>
        </div>
        <div class="item">
            <img src="https://picsum.photos/200/200" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <h1>Producto</h1>
                <p>Descripción</p>
                <a href="">Ver más</a>
            </div>
        </div>
        <div class="item">
            <img src="https://picsum.photos/200/200" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <h1>Producto</h1>
                <p>Descripción</p>
                <a href="">Ver más</a>
            </div>
        </div>
    </div>
</section>
<?php require_once('componentes/footer.php'); ?>