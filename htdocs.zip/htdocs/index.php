<?php require_once('utilidades/utilidad.php'); ?>
<?php $configuracion->setTitulo('Inicio'); ?>
<?php $configuracion->setMenu('Inicio'); ?>
<?php require_once('componentes/head.php'); ?>
<?php require_once('componentes/header.php'); ?>
<section id="contenido">
    <div class="banner">
        <i class="fa fa-home fa-3x" aria-hidden="true"></i>
        <div>
            <h1>Bienvenida</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laboriosam accusantium beatae earum aliquam expedita animi voluptatum esse harum maxime nihil facilis, quia nesciunt, illo magni error alias iste aperiam facere?</p>
        </div>
    </div>
    <div id="slider">
        hola
    </div>
    <div class="muestra">
    <div class="item">
            <div class="titulo">
                <h1>Productos</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                </ul>
            </div>
        </div>
        <div class="item">
            <div class="titulo">
                <h1>Servicios</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                </ul>
            </div>
        </div>
        <div class="item">
            <div class="titulo">
                <h1>Soporte</h1>
            </div>
            <img src="https://picsum.photos/150/150" alt="" srcset="" width="200px" height="200px">
            <div class="informacion">
                <ul>
                    <li>Uno</li>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php require_once('componentes/footer.php'); ?>