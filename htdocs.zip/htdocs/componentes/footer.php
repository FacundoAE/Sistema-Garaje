<footer id="footer">
    <span>Copyright &copy; <?=DATE('Y');?> <?=$configuracion->getDominio();?> - Todos los derechos reservados.</span>
</footer>
<script src="<?=$configuracion->getUrl();?>recursos/js/script.js"></script>
</section>
</body>
</html>