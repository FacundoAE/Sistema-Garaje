<header id="header">
<div id="header-left">
    <img src="<?=$configuracion->getUrl();?>recursos/img/logo.png" alt="Logo" width="60px" height="auto" draggable="false">

    <div>
        <h2><?=$configuracion->getNombre();?></h2>
        <span>Descripción para el sitio</span>
    </div>

</div>

<div id="header-right">

<a href="<?=$configuracion->getUrl();?>" class="header-box-icon<?=$configuracion->getMenu('Inicio'); ?>">
    <span class="header-box-icon-top"><i class="fa fa-home fa-lg" aria-hidden="true"></i></span>
    <span class="header-box-icon-bottom">Inicio</span>
</a>
<a href="<?=$configuracion->getUrl();?>nosotros" class="header-box-icon<?=$configuracion->getMenu('Nosotros'); ?>">
    <span class="header-box-icon-top"><i class="fa fa-users" aria-hidden="true"></i></span>
    <span class="header-box-icon-bottom">Nosotros</span>
</a>
<a href="<?=$configuracion->getUrl();?>productos" class="header-box-icon<?=$configuracion->getMenu('Productos'); ?>">
    <span class="header-box-icon-top"><i class="fa fa-cubes" aria-hidden="true"></i></span>
    <span class="header-box-icon-bottom">Productos</span>
</a>
<a href="<?=$configuracion->getUrl();?>servicios" class="header-box-icon<?=$configuracion->getMenu('Servicios'); ?>">
    <span class="header-box-icon-top"><i class="fa fa-desktop" aria-hidden="true"></i></span>
    <span class="header-box-icon-bottom">Servicios</span>
</a>
<a href="<?=$configuracion->getUrl();?>contacto" class="header-box-icon<?=$configuracion->getMenu('Contacto'); ?>">
    <span class="header-box-icon-top"><i class="fa fa-envelope" aria-hidden="true"></i></span>
    <span class="header-box-icon-bottom">Contacto</span>
</a>
    
</div>
</header>