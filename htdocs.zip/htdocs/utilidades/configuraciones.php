<?php 

namespace utilidades;

class configuraciones{

    private static string $titulo;
    private const NOMBRE = 'Empresa';
    private const DOMINIO = 'Empresa.com';
    private const URL = 'http://localhost:8080/';
    private static string $menu;

    public function __construct()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function getNombre(): string{
        return self::NOMBRE;
    }

    public function getDominio(): string{
        return self::DOMINIO;
    }

    public function getUrl(): string{
        return self::URL;
    }

    public static function setTitulo(string $texto): void{
        self::$titulo = $texto;
    }

    public function getTitulo(): string{
        return self::getNombre().' - '.self::$titulo;
    }

    public static function setMenu($texto): void{
        self::$menu = $texto;
    }

    public function getMenu($comprobar): string{

        $devuelve = '';
        
        if(self::$menu === $comprobar){
            $devuelve = ' header-box-active';
        }
        
        return $devuelve;
    }
}

?>