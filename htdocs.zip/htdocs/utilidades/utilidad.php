<?php 

require_once('utilidades/configuraciones.php');
use utilidades\Configuraciones;

$configuracion = new Configuraciones;

?>